//
//  departmentsTableViewController.swift
//  Assignment5
//
//  Created by pavan kumar chalumuri on 11/21/18.
//  Copyright © 2018 pavan kumar chalumuri. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class departmentsTableViewController: UITableViewController {
    
    let urlList = "https://bismarck.sdsu.edu/registration/subjectlist";
    @IBOutlet var tableViewConnection: UITableView!
    
    var mainListArray = [Subject]()
    var myIndex = 0
    
    public struct Subject: Decodable{
        
        public var id : Int!
        public var college : String!
        public var classes : Int!
        public var title : String!
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        loadSubjects()
        
    }
    
    func loadSubjects(){
        
        guard let url = URL(string: urlList) else {return}
        URLSession.shared.dataTask(with: url) { (data, response, err) in
            
            guard let data = data else {return}
            
            do{
                
                self.mainListArray = try JSONDecoder().decode([Subject].self, from: data)
                DispatchQueue.main.async {
                    self.tableViewConnection.reloadData()
                }
                
            } catch let jsonErr{
                print("error:", jsonErr)
            }
            }.resume()
        
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return mainListArray.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? departmentsTableViewCell else {return UITableViewCell()}
        
        let title = mainListArray[indexPath.row].title
        cell.titleLabel.text = title
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        myIndex = indexPath.row
        performSegue(withIdentifier: "subjectsToFiltration1", sender: self)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let filterAndControl = segue.destination as? filtrationViewController,
            let path = self.tableView.indexPathForSelectedRow{
            let subjectInfo = mainListArray[path.row]
            filterAndControl.subjectId = subjectInfo.id!
        }
    }
    
}
