//
//  CoursesTableViewController.swift
//  Assignment5
//
//  Created by pavan kumar chalumuri on 11/23/18.
//  Copyright © 2018 pavan kumar chalumuri. All rights reserved.
//

import UIKit

class CoursesTableViewController: UITableViewController {
    
    public struct Course: Decodable{
        public var building : String!
        public var course : String!
        public var days : String!
        public var department : String!
        public var descriptionField : String!
        public var endTime : String!
        public var enrolled : Int!
        public var fullTitle : String!
        public var id : Int!
        public var instructor : String!
        public var meetingType : String!
        public var prerequisite : String!
        public var room : String!
        public var schedule : String!
        public var seats : Int!
        public var section : String!
        public var startTime : String!
        public var subject : String!
        public var suffix : String!
        public var title : String!
        public var units : String!
        public var waitlist : Int!
        
    }
    
    var postData: [String: Any] = [String: Any]()
    @IBOutlet var coursesListTableView: UITableView!
    
    //var Course1: CourseStructure.Course
    var myIndex = 0;
    var coursesList = [Course]()
    let searchCoursesURL: String = "https://bismarck.sdsu.edu/registration/classidslist"
    let coursesListURL: String = "https://bismarck.sdsu.edu/registration/classdetails"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        HTTPRequest.postCall(data: self.postData, url: searchCoursesURL, onCompletion: getCoursesIds)
    }
    
    func getCoursesIds(data: Any){
        let coursesList = ["classids": data as! [Int]]
        print("like this we need")
        print(coursesList)
        self.postCallWithDecoder(data: coursesList, url: coursesListURL)
    }
    
    func postCallWithDecoder(data: [String: [Int]], url: String){
        print("Standard")
        let jsonData = try? JSONSerialization.data(withJSONObject: data)
        if let urlString = URL(string: url){
            
            var urlRequest = URLRequest(url: urlString)
            
            urlRequest.httpMethod = "POST"
            urlRequest.httpBody = jsonData
            urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
            
            let userTask = URLSession.shared.dataTask(with: urlRequest){
                (data, URLResponse, err)  in
                
                if err != nil {
                    print(err!)
                    return
                }
                
                guard let responseData = data else {
                    print( "no data buddy")
                    return
                }
                
                do{
                    self.coursesList = try JSONDecoder().decode([Course].self, from: responseData)
                    //print(self.coursesList)
                    
                    DispatchQueue.main.async {
                        self.coursesListTableView.reloadData()
                    }
                }catch {
                    
                    print(err?.localizedDescription as Any)
                }
            }
            userTask.resume()
        }
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return coursesList.count
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{
        
        return CGFloat(120.0)
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "courseDetailCell", for: indexPath)
        (cell.contentView.viewWithTag(3) as! UILabel).text = coursesList[indexPath.row].title
        (cell.contentView.viewWithTag(4) as! UILabel).text = coursesList[indexPath.row].instructor
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        myIndex = indexPath.row
        performSegue(withIdentifier: "coursesTableToCourseDetails", sender: self)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let coursesDetailsController = segue.destination as? CoursesDetailsController,
            let path = self.tableView.indexPathForSelectedRow{
            
            let courseId = coursesList[path.row].id
            coursesDetailsController.courseId = courseId
        }
    }
    
}
