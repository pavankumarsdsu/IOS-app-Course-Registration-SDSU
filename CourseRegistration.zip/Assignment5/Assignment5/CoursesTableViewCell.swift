//
//  CoursesTableViewCell.swift
//  Assignment5
//
//  Created by pavan kumar chalumuri on 11/24/18.
//  Copyright © 2018 pavan kumar chalumuri. All rights reserved.
//

import UIKit

class CoursesTableViewCell: UITableViewCell {
    
   
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var instructorLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
