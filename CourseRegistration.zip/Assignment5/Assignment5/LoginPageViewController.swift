//
//  LoginPageViewController.swift
//  Assignment5
//
//  Created by pavan kumar chalumuri on 11/16/18.
//  Copyright © 2018 pavan kumar chalumuri. All rights reserved.
//

import UIKit
import Firebase

class LoginPageViewController: UIViewController {
    
    @IBOutlet weak var emailtextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBAction func loginButtonPressed(_ sender: Any) {
        
        print( "inside login button")
        
        //        UserDefaults.standard.set(emailtextField.text, forKey: "emailLoggedIn")
        
        if let users = UserDefaults.standard.dictionary(forKey:"users") as? [String: Data] {
            print("inside first if loop")
            
            if let userStoredData = users[emailtextField.text!] {
                print("inside 2nd if loop")
                
                let userStoredValues = try? PropertyListDecoder().decode(RegisterPageViewController.newUser.self, from: userStoredData)
                print("retrieving password from userdefaults")
                print(userStoredValues?.password as Any)
                print("comparing stored password with the entered one")
                
                
                if userStoredValues?.password == passwordTextField.text {
                    self.performSegue(withIdentifier: "loginToWelcome", sender: self)
                    print("hey buddy you are successfully logged in !")
                } else {
                    
                    let myAlert = UIAlertController(title: "Error", message: "invalid password", preferredStyle: UIAlertController.Style.alert)
                    
                    let okAction = UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil)
                    
                    myAlert.addAction(okAction);
                    self.present(myAlert, animated: true, completion: nil)
                    return
                    
                }
                
            } else {
                
                let myAlert = UIAlertController(title: "Error", message: "invalid email id", preferredStyle: UIAlertController.Style.alert)
                
                let okAction = UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil)
                
                myAlert.addAction(okAction);
                self.present(myAlert, animated: true, completion: nil)
                return
                
            }
            
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
}


















