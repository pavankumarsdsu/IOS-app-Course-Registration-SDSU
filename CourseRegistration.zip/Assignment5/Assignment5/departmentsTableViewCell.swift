//
//  departmentsTableViewCell.swift
//  Assignment5
//
//  Created by pavan kumar chalumuri on 11/21/18.
//  Copyright © 2018 pavan kumar chalumuri. All rights reserved.
//

import UIKit

class departmentsTableViewCell: UITableViewCell {

    @IBOutlet var titleLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
