//
//  CoursesDetailsController.swift
//  Assignment5
//
//  Created by pavan kumar chalumuri on 11/23/18.
//  Copyright © 2018 pavan kumar chalumuri. All rights reserved.
//

import UIKit

class CoursesDetailsController: UIViewController {
    
    public var courseId: Int!
    let coursesListURL: String = "https://bismarck.sdsu.edu/registration/classdetails"
    let registerStudentURL: String = "https://bismarck.sdsu.edu/registration/registerclass"
    let waitlistURL: String = "https://bismarck.sdsu.edu/registration/waitlistclass"
    
    @IBOutlet weak var addButton: UIButton!
    
    
    @IBOutlet weak var courseFullTitle: UILabel!
    @IBOutlet weak var startTimeLabel: UILabel!
    @IBOutlet weak var endTimeLabel: UILabel!
    @IBOutlet weak var classLocationLabel: UILabel!
    
    func addClass(data: Any){

        print(data as! [String: Any])
        
        let resultDict = data as! [String: Any]
        switch resultDict.keys.first {
        case "ok":
            DispatchQueue.main.async {
                self.errorAlerts(Title: "Done!", Message: resultDict.values.first as! String)
                
            }
        default:
            
            DispatchQueue.main.async {
                self.errorAlerts(Title: "error", Message: resultDict.values.first as! String)
            }
        }
        
        
        let resultWaitlist = data as! [String: Any]
        guard let error = resultWaitlist["error"] else {return}
        print(error)
        
        let x = error as! String;
        let y = "Course is full"
        
        if y.elementsEqual(x) == true {
            
            waitlistClass()
            
        }
        
        
    
    }
    
    func waitlist(data: Any){
        print(data)
        let resultDict = data as! [String: Any]
        print("printing the error string")
        guard let error = resultDict["error"] else {return}
        print(error)

        let x = error as! String;
        let a = "Course added"
        let y = "Student already in waitlist"

        if a.elementsEqual(x) == true {

            self.errorAlerts(Title: "error", Message: "Done!. Course added to your waitlists")
        }

        else if y.elementsEqual(x) == true {

            self.errorAlerts(Title: "error", Message: "you are already waitlisted to this class. Please go back and check in your waitlisted classes")
        }
//        print(data as! [String: Any])
//
//        let resultDict = data as! [String: Any]
//        switch resultDict.keys.first {
//        case "ok":
//            DispatchQueue.main.async {
//                self.errorAlerts(Title: "Done!", Message: resultDict.values.first as! String)
//
//            }
//        default:
//
//            DispatchQueue.main.async {
//                self.errorAlerts(Title: "error", Message: resultDict.values.first as! String)
//            }
//        }
        
    }
    
    @IBAction func addClassButtonPressed(_ sender: Any) {
            registerClass()
        
    }
    
    
    func registerClass(){
        
        let email: String = UserDefaults.standard.value(forKey: "emailLoggedIn") as! String
        if let users = UserDefaults.standard.dictionary(forKey:"users") as? [String: Data] {
            
            if let userStoredData = users[email] {
                
                let userStoredValues = try? PropertyListDecoder().decode(RegisterPageViewController.newUser.self, from: userStoredData)
                
                if userStoredValues?.email == email {
                    let redid: String = (userStoredValues?.redId)!
                    let password: String = (userStoredValues?.password)!
                    
                    let data = ["redid": redid, "password": password, "courseid": courseId] as [String : Any]
                    HTTPRequest.postCall(data: data, url: registerStudentURL, onCompletion: addClass)
                    
                }
                
            }
            
        }
        
    }
    
    func waitlistClass() {
        
        let email: String = UserDefaults.standard.value(forKey: "emailLoggedIn") as! String
        if let users = UserDefaults.standard.dictionary(forKey:"users") as? [String: Data] {
            
            if let userStoredData = users[email] {
                
                let userStoredValues = try? PropertyListDecoder().decode(RegisterPageViewController.newUser.self, from: userStoredData)
                
                if userStoredValues?.email == email {
                    let redid: String = (userStoredValues?.redId)!
                    let password: String = (userStoredValues?.password)!
                    
                    print(redid)
                    
                    
                    let data = ["redid": redid, "password": password, "courseid": courseId] as [String : Any]
                    HTTPRequest.postCall(data: data, url: waitlistURL, onCompletion: waitlist)
                    
                }
                
            }
            
        }
        
        
        
        
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let coursesList = ["classids": [courseId!]]
        self.postCallWithDecoder(data: coursesList, url: coursesListURL)
        
    }
    
    func postCallWithDecoder(data: [String: [Int]], url: String){
        
        let jsonData = try? JSONSerialization.data(withJSONObject: data)
        if let urlString = URL(string: url){
            
            var urlRequest = URLRequest(url: urlString)
            
            urlRequest.httpMethod = "POST"
            urlRequest.httpBody = jsonData
            urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
            
            let userTask = URLSession.shared.dataTask(with: urlRequest){
                (data, URLResponse, err)  in
                
                
                if err != nil {
                    print("error")
                    print(err as Any)
                    return
                }
                
                guard let responseData = data else {
                    print( "no data buddy")
                    return
                }
                
                do{
                    let course: [CoursesTableViewController.Course] = try JSONDecoder().decode([CoursesTableViewController.Course].self, from: responseData)
                    DispatchQueue.main.async {
                        self.courseFullTitle.text = course[0].fullTitle
                        self.startTimeLabel.text = course[0].startTime
                        self.endTimeLabel.text = course[0].endTime
                        self.classLocationLabel.text =  course[0].building + ", "+course[0].room
                        
                        if (course[0].seats - course[0].enrolled == 0){
                            
                            self.classFullAlerts(Title: "error", Message: "class-full! Do you want to add the class to waitlist")
                            
                            
                        }
                        
                        
                    }
                }catch {
                    
                    print(err?.localizedDescription as Any)
                }
            }
            userTask.resume()
        }
    }
    
    func classFullAlerts(Title: String, Message: String){
        
        let myAlert = UIAlertController(title: Title, message: Message, preferredStyle: UIAlertController.Style.alert)
        
        let okAction = UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil)
        
        myAlert.addAction(okAction);
        self.present(myAlert, animated: true, completion: nil)
        addButton.setTitle("add to waitlist", for: .normal)
        return
        
    }
    
    func errorAlerts(Title: String, Message: String){
        
        let myAlert = UIAlertController(title: Title, message: Message, preferredStyle: UIAlertController.Style.alert)
        
        let okAction = UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil)
        
        myAlert.addAction(okAction);
        self.present(myAlert, animated: true, completion: nil)
        return
        
    }
    
    
    
    
}
