//
//  ViewController.swift
//  Assignment5
//
//  Created by pavan kumar chalumuri on 11/12/18.
//  Copyright © 2018 pavan kumar chalumuri. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

