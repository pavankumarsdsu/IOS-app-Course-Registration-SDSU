//
//  RegisterPageViewController.swift
//  Assignment5
//
//  Created by pavan kumar chalumuri on 11/16/18.
//  Copyright © 2018 pavan kumar chalumuri. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

class RegisterPageViewController: UIViewController {
    
    public struct newUser: Codable {
        
        var firstName: String?
        var lastName: String?
        var redId: String?
        var email: String?
        var password: String?
        
        init(firstName: String, lastName: String, redId: String, email: String, password: String){
            
            self.firstName = firstName
            self.lastName = lastName
            self.redId = redId
            self.email = email
            self.password = password
        }
        
    }
    
    @IBOutlet weak var firstNameTextField: UITextField!
    @IBOutlet weak var lastNameTextField: UITextField!
    @IBOutlet weak var redidTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    @IBAction func registerButtonPressed(_ sender: Any) {
        
        
        let firstName = firstNameTextField.text;
        let lastName = lastNameTextField.text;
        let redid = redidTextField.text;
        let email = emailTextField.text;
        let password = passwordTextField.text;
        
        //check for empty fields
        if(firstName!.isEmpty || lastName!.isEmpty || redid!.isEmpty || email!.isEmpty || password!.isEmpty){
            self.myAlerts(Title: "error", Message: "Please complete all the fields")
        }
        
        //emailValidation
        
        let isEmailAdressValid = isValidEmailAddress(inputEmail: email!)
        let isRedIdValid = isValidRedId(inputRedid: redid!)
        
        
        if isEmailAdressValid {
            if isRedIdValid {
            
                    callRegisterStudentAPI()
     
              } else{
                
                self.myAlerts(Title: "error", Message: "Please Enter a valid red id")
          }
            
        } else{
            
            self.myAlerts(Title: "error", Message: "Please Enter a valid email id")
        }
        
    }
    
    
    func storeUserData(){
        
        do{
            let user: newUser = newUser(firstName: firstNameTextField.text!, lastName: lastNameTextField.text!, redId: redidTextField.text!, email: emailTextField.text!, password: passwordTextField.text!)
            
            let uploadData = try PropertyListEncoder().encode(user)
            var userDict = [String: Data]()
            userDict[emailTextField.text!] = uploadData
            UserDefaults.standard.set(userDict, forKey: "users")
            
        } catch{
            print("some error has occured! while sasving the data in user defaults")
            
        }
    }
    
    
    
    func isValidEmailAddress(inputEmail: String) -> Bool {
        
        let emailPattern = "[A-Z0-9a-z.-_]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,3}"
        var emailResultBoolean = true
        
        do {
            let emailString = inputEmail as NSString
            let regex = try NSRegularExpression(pattern: emailPattern)
            let results = regex.matches(in: inputEmail, range: NSRange(location: 0, length: emailString.length))
            
            if results.count == 0
            {
                emailResultBoolean = false
            }
            
        } catch let error as NSError {
            print(error.localizedDescription)
            emailResultBoolean = false
        }
        
        return  emailResultBoolean
    }
    
    
    
    func isValidPassword(inputPassword: String) -> Bool {
        
        let passwordPattern = "\\d{8.}"
        var passwordResultBoolean = true
        
        do {
            let passwordString = inputPassword as NSString
            let regex = try NSRegularExpression(pattern: passwordPattern)
            let results = regex.matches(in: inputPassword, range: NSRange(location: 0, length: passwordString.length))
            
            if results.count == 0
            {
                passwordResultBoolean = false
            }
            
        } catch let error as NSError {
            print(error.localizedDescription)
            passwordResultBoolean = false
        }
        
        return  passwordResultBoolean
    }
    
    
    
    func isValidRedId(inputRedid: String) -> Bool {
        
        let redidPattern = "^\\d{5}1458"
        var redidResultBoolean = true
        
        do {
            let redidString = inputRedid as NSString
            let regex = try NSRegularExpression(pattern: redidPattern)
            let results = regex.matches(in: inputRedid, range: NSRange(location: 0, length: redidString.length))
            
            if results.count == 0
            {
                redidResultBoolean = false
            }
            
        } catch let error as NSError {
            print(error.localizedDescription)
            redidResultBoolean = false
        }
        
        return  redidResultBoolean
    }
    
    func myAlerts(Title: String, Message: String){
        
        let myAlert = UIAlertController(title: Title, message: Message, preferredStyle: UIAlertController.Style.alert)
        
        let okAction = UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil)
        
        myAlert.addAction(okAction);
        self.present(myAlert, animated: true, completion: nil)
        return
        
    }
    
    func callRegisterStudentAPI(){
        
        let registerStudentURL: String = "https://bismarck.sdsu.edu/registration/addstudent"
        let data = ["firstname": firstNameTextField.text as Any, "lastname": lastNameTextField.text as Any, "redid": redidTextField.text as Any, "email": emailTextField.text as Any,"password": passwordTextField.text as Any] as [String : Any]
        HTTPRequest.postCall(data: data, url: registerStudentURL, onCompletion: registerStudent)
        
        
    }
    
    func registerStudent(data: Any){
        print(data as! [String: Any])
        
        let resultDict = data as! [String: Any]
        switch resultDict.keys.first {
        case "ok":
            DispatchQueue.main.async {
                self.storeUserData()
                UserDefaults.standard.set(self.emailTextField.text, forKey: "emailLoggedIn")
                self.performSegue(withIdentifier: "registrationToWelcome", sender: self)
                
                            }
        default:
            
            DispatchQueue.main.async {
            self.myAlerts(Title: "error", Message: resultDict.values.first as! String)
            }
        }

        }
    
    }










