//
//  waitlistedClassesTableViewController.swift
//  Assignment5
//
//  Created by pavan kumar chalumuri on 11/26/18.
//  Copyright © 2018 pavan kumar chalumuri. All rights reserved.
//
import UIKit

class waitlistedClassesTableViewController: UITableViewController {
    
    @IBOutlet var mainTableView: UITableView!
    
    public struct Course: Decodable{
        public var building : String!
        public var course : String!
        public var days : String!
        public var department : String!
        public var descriptionField : String!
        public var endTime : String!
        public var enrolled : Int!
        public var fullTitle : String!
        public var id : Int!
        public var instructor : String!
        public var meetingType : String!
        public var prerequisite : String!
        public var room : String!
        public var schedule : String!
        public var seats : Int!
        public var section : String!
        public var startTime : String!
        public var subject : String!
        public var suffix : String!
        public var title : String!
        public var units : String!
        public var waitlist : Int!
        
    }
    
    public var redid: String = ""
    public var password: String = ""
    var myIndex = 0;
    var coursesList = [Course]()
    let searchCoursesURL: String = "https://bismarck.sdsu.edu/registration/studentclasses"
    let coursesListURL: String = "https://bismarck.sdsu.edu/registration/classdetails"
    
    
    public struct registeredClasses: Decodable{
        public var classes: [Int?]
        public var waitlist: [Int?]
    }
    var registeredClassesList = [registeredClasses]()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let email: String = UserDefaults.standard.value(forKey: "emailLoggedIn") as! String
        
        if let users = UserDefaults.standard.dictionary(forKey:"users") as? [String: Data] {
            
            if let userStoredData = users[email] {
                
                let userStoredValues = try? PropertyListDecoder().decode(RegisterPageViewController.newUser.self, from: userStoredData)
                
                if userStoredValues?.email == email {
                    let redid = (userStoredValues?.redId)!
                    let password = (userStoredValues?.password)!
                    let postData = ["redid": redid, "password": password] as [String : Any]
                    HTTPRequest.postCall(data: postData, url: searchCoursesURL, onCompletion: getCoursesIds)
                }
                
            }
            
        }
        
    }
    
    func getCoursesIds(data: Any){
        print("we got data from registered classes URL");
        print(data)
        let studentClassesDict = data as! [String:[Int]]
        guard let waitlistClasses = studentClassesDict["waitlist"] else {return}
        
        print("waitlist classes list")
        print(waitlistClasses)
        
        
        let wcoursesList = ["classids": waitlistClasses]
        print("this is the one we are sending it to get the course details of registered classes to get wait list subjects")
        print(wcoursesList)
        self.postCallWithDecoder(data: wcoursesList, url: coursesListURL)
    }
    
    func postCallWithDecoder(data: [String: [Int]], url: String){
        print("start")
        let jsonData = try? JSONSerialization.data(withJSONObject: data)
        if let urlString = URL(string: url){
            
            var urlRequest = URLRequest(url: urlString)
            
            urlRequest.httpMethod = "POST"
            urlRequest.httpBody = jsonData
            urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
            
            let userTask = URLSession.shared.dataTask(with: urlRequest){
                (data, URLResponse, err)  in
                
                if err != nil {
                    print(err!)
                    return
                }
                
                guard let responseData = data else {
                    print( "no data buddy")
                    return
                }
                
                do{
                    print("in")
                    self.coursesList = try JSONDecoder().decode([Course].self, from: responseData)
                    print(self.coursesList)
                    
                    DispatchQueue.main.async {
                        self.mainTableView.reloadData()
                    }
                }catch {
                    
                    print(err?.localizedDescription as Any)
                }
            }
            userTask.resume()
        }
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return coursesList.count
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{
        
        return CGFloat(300.0)
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "waitlistedClasses", for: indexPath)
        (cell.contentView.viewWithTag(3) as! UILabel).text = coursesList[indexPath.row].title
        (cell.contentView.viewWithTag(4) as! UILabel).text = coursesList[indexPath.row].instructor
        let courseId = String(coursesList[indexPath.row].id)
        (cell.contentView.viewWithTag(6) as! UILabel).text = courseId
        
        return cell
    }
    
    @IBAction func dropButtonPressed(_ sender: Any) {
        
        let dropClassURL: String = "https://bismarck.sdsu.edu/registration/unwaitlistclass"
        
        let email: String = UserDefaults.standard.value(forKey: "emailLoggedIn") as! String
        
        if let users = UserDefaults.standard.dictionary(forKey:"users") as? [String: Data] {
            
            if let userStoredData = users[email] {
                
                let userStoredValues = try? PropertyListDecoder().decode(RegisterPageViewController.newUser.self, from: userStoredData)
                
                if userStoredValues?.email == email {
                    let redid: String = (userStoredValues?.redId)!
                    let password: String = (userStoredValues?.password)!
                    let clickPosition:CGPoint = (sender as AnyObject).convert(CGPoint.zero, to:self.tableView)
                    let indexPath = self.tableView.indexPathForRow(at: clickPosition)
                    guard let courseId =  coursesList[indexPath!.row].id else {return}
                    
                    print("this is the course to be dropped from waitlist")
                    print(courseId)
                    let data = ["redid": redid, "password": password, "courseid": courseId] as [String : Any]
                    HTTPRequest.postCall(data: data, url: dropClassURL, onCompletion: dropClass)
                    
                }
            }
        }
        
    }
    
    func dropClass(data: Any){
        print(data)
        
        super.viewDidLoad()
        let email: String = UserDefaults.standard.value(forKey: "emailLoggedIn") as! String
        
        if let users = UserDefaults.standard.dictionary(forKey:"users") as? [String: Data] {
            
            if let userStoredData = users[email] {
                
                let userStoredValues = try? PropertyListDecoder().decode(RegisterPageViewController.newUser.self, from: userStoredData)
                
                if userStoredValues?.email == email {
                    let redid = (userStoredValues?.redId)!
                    let password = (userStoredValues?.password)!
                    let postData = ["redid": redid, "password": password] as [String : Any]
                    HTTPRequest.postCall(data: postData, url: searchCoursesURL, onCompletion: getCoursesIds)
                }
                
            }
            
        }
        
    }
    
}
