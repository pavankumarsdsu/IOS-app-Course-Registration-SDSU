//
//  filtrationViewController.swift
//  Assignment5
//
//  Created by pavan kumar chalumuri on 11/23/18.
//  Copyright © 2018 pavan kumar chalumuri. All rights reserved.
//

import UIKit

class filtrationViewController: UIViewController,UIPickerViewDelegate, UIPickerViewDataSource {
    
    public var subjectId: Int!
    var courseIds: [Int] = [];
    var grades = ["lower", "upper", "Graduate"]
    var pickerViewSelection: String = ""
    var postData = [String : Any]()
    
    @IBOutlet weak var gradePick: UIPickerView!
    @IBOutlet weak var startTimeTextField: UITextField!
    @IBOutlet weak var endTimeTextField: UITextField!
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return grades.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return grades[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        pickerViewSelection = grades[row]
        return
    }
    
    @IBAction func searchButtonPressed(_ sender: Any) {
        
        postData = ["subjectids": [subjectId!], "level": pickerViewSelection, "starttime": startTimeTextField.text!]
        
        print("subject id is ")
        print(subjectId!)
        
        
        print("picker view selection is")
        print(pickerViewSelection)
        
        print("start time selected is")
        print(startTimeTextField.text!)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        gradePick.delegate = self
        gradePick.dataSource = self
        pickerViewSelection = grades[0]
        startTimeTextField.placeholder = "HHmm"
        endTimeTextField.placeholder = "HHmm"
        self.startTimeTextField.keyboardType = UIKeyboardType.decimalPad
        self.endTimeTextField.keyboardType = UIKeyboardType.decimalPad
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        postData = ["subjectids": [subjectId!], "level": pickerViewSelection, "starttime": startTimeTextField.text!]
        
        if let courseListController = segue.destination as? CoursesTableViewController {
            courseListController.postData = postData
        }
        print("need answer")
        print(postData);
    }
    
}
