//
//  WelocmePageViewController.swift
//  Assignment5
//
//  Created by pavan kumar chalumuri on 11/16/18.
//  Copyright © 2018 pavan kumar chalumuri. All rights reserved.
//

import UIKit
import Firebase


class WelocmePageViewController: UIViewController {
    
    @IBOutlet weak var emailLoggedIn: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        emailLoggedIn.text! = UserDefaults.standard.value(forKey: "emailLoggedIn") as! String
    }
    
    func resetRegistration(data: Any){
        print(data)
    }
    
    @IBAction func resetRegistrationButtonPressed(_ sender: Any) {
        
        let email: String = UserDefaults.standard.value(forKey: "emailLoggedIn") as! String
        
        if let users = UserDefaults.standard.dictionary(forKey:"users") as? [String: Data] {
            
            if let userStoredData = users[email] {
                
                let userStoredValues = try? PropertyListDecoder().decode(RegisterPageViewController.newUser.self, from: userStoredData)
                
                if userStoredValues?.email == email {
                    let redid = (userStoredValues?.redId)!
                    let password = (userStoredValues?.password)!
                    
                    print(redid)
                    print(password)
                    let resetURL: String = "https://bismarck.sdsu.edu/registration/resetstudent?redid=\(redid)&password=\(password)"
                    print(" resposnse from reset")
                    guard let url = URL(string: resetURL) else {return}
                    URLSession.shared.dataTask(with: url) { (data, response, err) in
                        
                        if err != nil {
                            print("error")
                            print(err!)
                            return
                        }
                        
                        guard let responseData = data else {
                            print( "no data buddy")
                            return
                        }
                        
                        do{
                            let res: Any = try JSONSerialization.jsonObject(with: responseData, options: [])
                            print(res)
                            
                        } catch {
                            print("error")
                        }
                        }.resume()
                }
                
            }
            
        }
        
    }
    
    
    
}




