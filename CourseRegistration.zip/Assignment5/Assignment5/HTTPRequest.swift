//
//  HTTPRequest.swift
//  Assignment5
//
//  Created by pavan kumar chalumuri on 11/23/18.
//  Copyright © 2018 pavan kumar chalumuri. All rights reserved.
//

import Foundation

class HTTPRequest {
    
    static func postCall(data: [String: Any], url: String, onCompletion: @escaping (Any) -> ()) {
        
        let jsonData = try? JSONSerialization.data(withJSONObject: data)
        if let urlString = URL(string: url){
            
            var urlRequest = URLRequest(url: urlString)
            urlRequest.httpMethod = "POST"
            urlRequest.httpBody = jsonData
            urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
            
            let userTask = URLSession.shared.dataTask(with: urlRequest){
                (data, URLResponse, err) in
                
                
                if err != nil {
                    print("error")
                    print(err!)
                    return
                }
                
                guard let responseData = data else {
                    print( "no data buddy")
                    return
                }
                
                do{
                    let res: Any = try JSONSerialization.jsonObject(with: responseData, options: [])
                    print(res)
                    onCompletion(res)
                }catch {
                    
                    print(err?.localizedDescription as Any)
                }
            }
            userTask.resume()
        }
        
        
    }
}
